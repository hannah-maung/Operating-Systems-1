


Instructions on how to compile my movies.c code:

gcc --std=gnu99 -o movies movies.c
./movies student_info1.txt





