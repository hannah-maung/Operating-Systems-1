
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**************************
 * Name: Hannah Maung
 * Date: 4/09/21
 * Assignment: Homework 1- Movies
 * Description: This program reads a CSV file with movie data provided as an argument.
 * It processes the data to create structs to hold data for each movie and creates a 
 * linked list for all of these structs. It then asks the user to enter a choice out of
 * four choices and prints out the data about the movies per user choice.
 **********************/


//struct for movie information
struct movie {

	char *title;
	int year;
	char *language;
	float rating;
	struct movie *next;

};


//parse current line which is space delimited and create a movie struct with the data in this line
////float and int variables do not need to allocate memory, only char variables 
struct movie *createMovie(char *currLine){

	struct movie *currMovie = malloc(sizeof(struct movie));

	char *saveptr;

	//The first token is the title
	char *token = strtok_r(currLine, ",", &saveptr);
	currMovie->title = calloc(strlen(token) +1, sizeof(char));
	strcpy(currMovie->title, token);

	//THe second token is the year 
	token = strtok_r(NULL, ",", &saveptr);
	currMovie->year = atoi(token);

	//The third token is the language
	token = strtok_r(NULL, ",", &saveptr);
	currMovie->language = calloc(strlen(token) +1, sizeof(char));
	strcpy(currMovie->language, token);
	
	//The last token is the rating
	token = strtok_r(NULL, " ", &saveptr);
	currMovie->rating = atof(token);
	
	//sets the next node to NULL in the newly created movie entry
	currMovie->next = NULL;
	return currMovie;
}


//return a linked list of movies by parsing data from each life of the file. 
struct movie *processFile(char *filePath) {

	//opens the file for reading only
	FILE *movieFile = fopen(filePath, "r");
	char *currLine = NULL;
	size_t len = 0;
	size_t nread;
	char *token;

	int count;

	//declares head and tail of linked list
	struct movie *head = NULL;
	struct movie *tail = NULL;

	//reads the file line by line
	while ((nread = getline(&currLine, &len, movieFile)) != -1) {

		//gets a new student node corressponding to the current line
		struct movie *newNode = createMovie(currLine);

		//if this the first node in the listed list then..	
		if (head == NULL) {
			//sets first node in the linked list, sets the head and tail to this node 
			head = newNode;
			tail = newNode;
	
		}

		else{
			//not the first node, adds this node to the list and advances the tail
			tail->next = newNode;
			tail = newNode;
		}
		count++;
	}

	free(currLine);
	fclose(movieFile);
	return head;
}	


//prints out the linked list of movies, returns the number of movies there are
int printMovieList(struct movie *list) {

	int count = 0;
	
	while (list != NULL) {
		list = list->next;
		count++;

	}
	return count;

}


//This function shows movies released in the specific year
void show_movies_year(struct movie *list, int yearinput, int count) {

	//while loop as long as list is not null
	int check = 0;
	while (list != NULL) {
		//if the year matches with the input that the user enters 
		if(list->year == yearinput) {
			//prints out the title of the movie 
			printf("%s\n",list->title);
			list = list->next;
			check++;
		}
		else{
			list = list->next;
		}

	}
	//prints out if check is 0, meaning that there are no movies in the year the user entered
	if(check == 0) {
		printf("No movies released in the year you entered");
	}	
}

//shows the highest rated movie for each year 
void show_movies_language(struct movie *list, char languageinput[], int count) {


	char *p;
	int check;
	//as long as list is not null, run this while loop 
	while (list != NULL) {
		//uses strstr to find the first occurence of the substring needle in the string haystack
		p = strstr(list->language,languageinput);
		if(p){
			//if it finds a match, print out the movie's year and title 
			printf("%d %s\n",list->year,list->title);
			list = list->next;
			check++;
			
		}
			//else moves onto next
		else{
			list = list->next;
		}
	}
	//prints out if check is 0, meaming that there is no data about movies released in that language
	if (check == 0) {
		printf("No data about movies released in %s",languageinput);

	}
}

//finds the highest rated movie for that year 
void highest_rated_movie_year(struct movie *list) {

	//for loop that iterates for years 1000 to 5000
	for (int year = 1000; year <= 5000; year++) {

		//creating a new struct to hold values 
		float r = 0.0;
		struct movie* high = NULL;
		struct movie *this = list;
		//as long as this is not NULL...
		while (this != NULL) {
			//if year in struct is equal to the year in the list 
			if (this->year == year) {	
				//if rating is equal to the rating in the list	
				if (this->rating > r) {
					r = this->rating;
					high = this;

				}

			} 
			this = this->next;
		}
		//if high is not null, print out the year, rating and the title 
		if (high != NULL) {
			printf("%d %0.1f %s\n", high->year, high->rating, high->title);

		}
	}
}	

//int main function, command line arguments
////argc is the argument count and argv is the argument vector
int main(int argc, char *argv[]) {

	//error checking for command line argument
	if (argc < 2) {
		printf("You must provide the name of the file to process\n");
		printf("For example: ./movies movies.txt\n");
		return EXIT_FAILURE;

	}
	
	//printing out the message about process file and movies correctly 
	struct movie *list = processFile(argv[1]);
	char *fileName = argv[1];
	//calling this function which returns an int, in this case the count which is the number of movies in the text file 
	int count = printMovieList(list);
	printf("Process file %s and parsed data for %d movies\n",fileName,count);

	//declaring variables for loop
	int x = 0;
	int choice;
	int yearinput;
	char languageinput[1000];
	while (!x) {
		//printing out the user options for movie data 
		printf("\n\n1. Show movies released in the specified year\n");
		printf("2. Show highest rated movie for each year\n");
		printf("3. Show the title and year of release of all movies in a specific language\n");
		printf("4. Exit from the program\n\n");
		printf("Enter a choice from 1 to 4:  ");
		scanf("%d", &choice);
		//switch statement for each option 
		switch(choice){

			//case 1 calls show_movies_year, asks user the first case, saves the input and calls function. the function returns the answer based off of the user input 
			case 1:
				printf("\nEnter the year for which you want to see movies: ");
				scanf("%d",&yearinput);
				show_movies_year(list,yearinput,count);
				break;
			//case 2 calls highest_rated_movie_year which shows the higest rated movie in each year in the txt file 
			case 2:
				highest_rated_movie_year(list);
				break;
			//case 3 calls show_movies_language, asks user the third case, saves the input and calls the function. the function returns the answer based off of the user language input
			case 3: 
				printf("\nEnter the language for which you want to see movies: ");
				scanf("%s",&languageinput);
				show_movies_language(list,languageinput,count);
				break;
			//exits program if user enters a 4
			case 4:
				x = 0;
				exit(0); 
			//default case in case the user does not enter a 1-4 value 
			default:
				printf("You entered an incorrect choice. Try again.\n\n");
		}
	}
}
