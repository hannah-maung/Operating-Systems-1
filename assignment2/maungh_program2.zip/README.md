Instructions on how to run the program:

--std=gnu99 -o movies_by_year movies_by_year.c
./movies_by_year
