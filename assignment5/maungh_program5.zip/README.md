Name: Hannah Maung 
Assignment 5: One-Time Pads
Main sources: 
- https://en.wikipedia.org/wiki/One-time_pad
- Module codes
- server.c and client.c programs 

How to run: 
./p5testscript RANDOM_PORT1 RANDOM_PORT2 > mytestresults
port number > 50000 (recommended)
