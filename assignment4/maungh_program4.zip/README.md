Name: Hannah Maung
Program 4

compile code instructions:
-pthread -o line_processor line_processor.c

options:
./line_processor
./line_processor < input1.txt
./line_processor < input1.txt > output1.txt
